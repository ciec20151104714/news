package com.tre.news.service;

public interface LoginService {
    public int countAllByUserNameAndPassword(String username, String password);

}
