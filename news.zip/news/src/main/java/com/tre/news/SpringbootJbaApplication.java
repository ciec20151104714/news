package com.tre.news;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJbaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootJbaApplication.class, args);
    }

}
